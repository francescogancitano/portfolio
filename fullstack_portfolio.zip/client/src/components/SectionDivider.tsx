/**
 * SectionDivider Component - Aurora UI Claymorphic
 * SVG wave divider between sections
 */

interface SectionDividerProps {
  color?: string;
  height?: number;
  flip?: boolean;
}

export default function SectionDivider({
  color = '#00D9FF',
  height = 100,
  flip = false,
}: SectionDividerProps) {
  return (
    <div className="relative w-full overflow-hidden" style={{ height }}>
      <svg
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
        className="w-full h-full"
        style={{ transform: flip ? 'scaleY(-1)' : 'none' }}
      >
        <path
          d="M0,50 Q300,0 600,50 T1200,50 L1200,120 L0,120 Z"
          fill={color}
          opacity="0.1"
        />
        <path
          d="M0,60 Q300,20 600,60 T1200,60 L1200,120 L0,120 Z"
          fill={color}
          opacity="0.05"
        />
      </svg>
    </div>
  );
}
