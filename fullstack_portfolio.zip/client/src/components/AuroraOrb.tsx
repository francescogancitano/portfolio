import { motion } from 'framer-motion';

/**
 * AuroraOrb Component - Aurora UI Claymorphic
 * Animated decorative orbs with aurora colors
 * Used for visual interest and section transitions
 */

interface AuroraOrbProps {
  color: 'cyan' | 'magenta' | 'gold' | 'purple';
  size: 'sm' | 'md' | 'lg';
  delay?: number;
  duration?: number;
  className?: string;
}

export default function AuroraOrb({ 
  color, 
  size = 'md', 
  delay = 0, 
  duration = 6,
  className = '' 
}: AuroraOrbProps) {
  const colorMap = {
    cyan: 'from-aurora-cyan/80 to-aurora-cyan/20',
    magenta: 'from-aurora-magenta/80 to-aurora-magenta/20',
    gold: 'from-aurora-gold/80 to-aurora-gold/20',
    purple: 'from-purple-500/80 to-purple-500/20',
  };

  const sizeMap = {
    sm: 'w-24 h-24',
    md: 'w-40 h-40',
    lg: 'w-64 h-64',
  };

  return (
    <motion.div
      className={`absolute rounded-full blur-3xl pointer-events-none ${sizeMap[size]} bg-gradient-radial ${colorMap[color]} ${className}`}
      animate={{
        y: [0, 20, -20, 0],
        x: [0, 15, -15, 0],
        opacity: [0.3, 0.6, 0.3, 0.3],
      }}
      transition={{
        duration,
        delay,
        repeat: Infinity,
        ease: 'easeInOut' as any,
      }}
    />
  );
}
